<?php

namespace App\Http\Controllers;

use App\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public function test1(){
        //增加
    	$student = DB::insert('Insert into student(name,age) values(?,?)',
            ['cool',11]
            );
    	var_dump($student);
        //修改
        $num = DB::update('update student set age = ? where name = ?',
            [33,'cool']);
        var_dump($num);
        //查询
        $student = DB::select('select * from student where id > ? ',[1]);
        dd($student);
        //删除
        $num = DB::delete('delete from student where id = ?',[2]);
        var_dump($num);

    }

    //构造器新增操作
    public function insert1(){
        //获取插入id
//        $num = DB::table('student')->insertGetId([
//            'name'=>'name1','age'=>11
//        ]);
        //批量插入数据
        $bool = DB::table('student')->insert([
            ['name'=>'name1','age'=>11],
            ['name'=>'name2','age'=>22],
        ]);
        var_dump($bool);
    }
    //构造器更新操作
    public function update1(){
        //更新
//        $num = DB::table('student')->where('name','name1')->update(
//            ['age'=>44]
//        );

        //自增自减increment/decrement
//        $num = DB::table('student')->where('name','name1')->increment('age',3);
        //增减的同时修改其它字段
        $num = DB::table('student')->where('name','name1')->increment('age',3,['sex'=>1]);
        var_dump($num);
    }

    //构造器删除操作
    public function delete1(){
        $num = DB::table('student')->where([['id','>',4],['name','like','name2']])->delete();
        var_dump($num);
        //清空表
        //DB::table('student')->truncate();
    }

    //构造器查询操作
    public function query1(){
        $student = DB::table('student')->get();
        $first = DB::table('student')->orderBy('id','desc')->first();
        $student = DB::table('student')->whereRaw('id >= ? and age >=?',[4,33])->get();

        //pluck,将指定字段输出成一个数组，只带一个参数的时候用默认的数字键名，两个参数的时候以第二个参数作为键名，第一个参数为键值
        //lists也是一样的用法
        $pl = DB::table('student')->pluck('age','name');

        //select 只输出指定字段
//        $student = DB::table('student')->select('name','age')->get();

        echo '<pre>';
        //chunk 每次只查询一定条数,orderby必带
        $student = DB::table('student')->orderBy('id')->chunk(2,function($students){
            var_dump($students);

        });

//        dd($student);
    }

    //聚合函数
    public function group1(){
        $num = DB::table('student')->count();
        $min = DB::table('student')->min('age');
        $max = DB::table('student')->max('age');
        $avg = DB::table('student')->avg('age');
        $sum = DB::table('student')->sum('age');
        var_dump($avg);
    }

    //orm模型
    public function orm1(){
        $students = Student::all();
        $students = Student::get();
        $student = Student::find(4);
        $student = Student::where('id','>',4)->orderBy('age','desc')->get();
        $count = Student::count();
//        dd($student);
        echo '<pre>';
         Student :: chunk(2,function($students){
            var_dump($students);
        });

    }

    //增加数据
    public function ormInsert(){
        //使用模型新增数据
//        $student = new Student();
//        $student->name = 'ormName';
//        $student->age = 55;
//        $bool= $student->save();
//         $student = Student::find(19);
//         $create_time = $student->created_at;

        //使用模型的Create方法新增数据
//        $student = Student::Create(['name'=>'jeff','age'=>22]);
        // 如果满足条件则插入，不满足则不插入
        $student = Student::firstOrCreate(['name'=>'jeff1']);
        //满足条件之后执行save即可插入
        $student = Student::firstOrNew(['name'=>'jeff1']);
        $bool = $student->save();

        var_dump($student);
    }

    //修改数据
    public function ormUpdate(){
        //使用模型修改数据
//        $student = Student::find(20);
//        $student->name = 'new jeff';
//        $bool = $student->save();
        //批量修改
        $num = Student :: where('id','>',19)->update(['name'=>'old jeff']);
        var_dump($num);
    }

    //删除数据
    public function ormDelete(){
        //使用模型删除数据
//        $student = Student::find(9);
//        $num = $student->delete();

        //使用主键删除
//        $num = Student::destroy([16,17]);

        //使用条件删除
        $num = Student::where('id','<',4)->delete();
        var_dump($num);
    }
}
